﻿use Mvc_02

SELECT *
FROM AspNetUsers